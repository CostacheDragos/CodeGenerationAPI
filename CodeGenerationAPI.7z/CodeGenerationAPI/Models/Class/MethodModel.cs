﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeGenerationAPI.Models.Variable;

namespace CodeGenerationAPI.Models.Class
{
    public class MethodModel
    {
        public string Name { get; set; } = string.Empty;
        public string AccessModifier { get; set; } = string.Empty;
        public DataTypeModel ReturnType { get; set; } = new();
        public List<VariableModel>? Parameters { get; set; }
        public bool IsVirtual { get; set; } = false;
        public bool IsStatic { get; set; } = false;
    }
}
